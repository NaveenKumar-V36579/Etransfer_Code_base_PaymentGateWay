import React, { Component } from "react";

class ComingSoonPage extends Component {
  render() {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItem: "center",
          alignSelf: "center",
          fontSize: "42px",
          color: "#00a7e1",
          marginTop:"20%"
        }}
      >
        Coming soon
      </div>
    );
  }
}

export default ComingSoonPage;
