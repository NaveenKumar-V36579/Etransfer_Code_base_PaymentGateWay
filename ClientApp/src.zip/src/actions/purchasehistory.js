export const GET_PURCHASE_HISTORY = "GET_PURCHASE_HISTORY";

export const actionCreators = {
    getPurchaseHistory: () => ({ type: GET_PURCHASE_HISTORY }),
    
};